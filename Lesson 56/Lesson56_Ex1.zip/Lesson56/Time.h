#pragma once
class Time {
    int hour;
    int minute;
    int second;
public:
    Time();
    Time(int, int, int);
    void showTimeUniversal() const;
    int getHour() const;
    int getMinute() const;
    int getSecond() const;
    void setHour(int hour);
    void setMinute(int minute);
    void setSecond(int second);
};
