﻿#pragma once
#include <iostream>
#include <string>
using namespace std;

/**
 * @author Branium Academy
 * @website braniumacademy.net
 * @version 2021.05
 */

class Smartphone {
private:
	static int autoId;	// mã sản phẩm tự động tăng
	int id;				// mã sản phẩm
	string manufacturer; // nhà sản xuất
	string productName;	// tên sản phẩm
	int price;		    // giá bán
	int ram;			// bộ nhớ ram
	int externalMem;	// bộ nhớ ngoài
	string dateOfManufacture; // ngày sản xuất
public:
	Smartphone() {
		id = 0;
		manufacturer = "";
		productName = "";
		ram = 0;
		price = 0;
		externalMem = 0;
		dateOfManufacture = "";
	}

	Smartphone(const int id) : id(id) {}

	Smartphone(const int id, const string manufacturer, const string productName,
		const int price, const int ram, const int externalMem, const string dom);

	void createInfo();

	void showInfo();

	int compareByPrice(const Smartphone& other) const;

	int compareByproductName(const Smartphone& other) const;
	// getter and setter:
	int getId() const { return id; }

	void setId(const int id);

	string getManufacturer() const { return manufacturer; }

	string getProductName() const { return productName; }

	void setManufacturer(const string manufacturer) { this->manufacturer = manufacturer; }

	void setProductName(const string productName) { this->productName = productName; }

	int getPrice() const { return price; }

	void setPrice(const int price) { this->price = price; }

	int getRam() const { return ram; }

	void setRam(const int amount) { ram = amount; }

	int getExternalMem() const { return externalMem; }

	string getDOM() const { return dateOfManufacture; }

	void setDOM(const string dom) { this->dateOfManufacture = dom; }

	static void setAutoId(const int value) { autoId = value; }

	static int getAutoId() { return autoId; }
};
