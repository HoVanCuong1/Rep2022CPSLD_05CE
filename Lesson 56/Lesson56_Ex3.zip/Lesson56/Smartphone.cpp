﻿#include <iomanip>
#include "Smartphone.h"

/**
 * @author Branium Academy
 * @website braniumacademy.net
 * @version 2021.05
 */

Smartphone::Smartphone(const int id, const string manuf, const string name,
	const int price, const int ram, const int externalMem, const string dom) :
	price(price), ram(ram), externalMem(externalMem) {
	setId(id);
	this->manufacturer = manuf;
	this->productName = name;
	this->dateOfManufacture = dom;
}

void Smartphone::createInfo() {
	id = autoId++;
	cout << "Ten san pham: ";
	cin.ignore();
	getline(cin, productName);
	cout << "Hang san xuat: ";
	getline(cin, manufacturer);
	cout << "Bo nho RAM: ";
	cin >> ram;
	cout << "Bo nho ngoai: ";
	cin >> externalMem;
	cout << "Ngay san xuat: ";
	cin.ignore();
	getline(cin, dateOfManufacture);
	cout << "Gia ban: ";
	cin >> price;
}

void Smartphone::setId(const int id) {
	if (id == 0) {
		this->id = autoId++;
	}
	else {
		this->id = id;
	}
}

void Smartphone::showInfo() {
	cout << left << setw(10) << id << setw(20) << productName
		<< setw(20) << manufacturer << setw(15) << price
		<< setw(15) << ram << setw(15) << externalMem
		<< setw(20) << dateOfManufacture << endl;
}

int Smartphone::compareByproductName(const Smartphone& other) const {
	return productName.compare(other.productName);
}

int Smartphone::compareByPrice(const Smartphone& other) const {
	return price - other.price;
}

int Smartphone::autoId = 10000; // gán giá trị cho biến static id của lớp
