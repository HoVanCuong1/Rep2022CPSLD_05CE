﻿#include <iostream>
#include <string>
using namespace std;

#pragma once

/**
 * @author Branium Academy
 * @website braniumacademy.net
 * @version 2021.05
 */

class Smartphone {
private:
	static int autoId;	// mã sản phẩm tự động tăng
	int id;				// mã sản phẩm
	string brand;		// hãng
	string name;		// tên sản phẩm
	float price;		// giá bán
	int ram;			// bộ nhớ ram
	int externalMem;	// bộ nhớ ngoài
	string dateOfManufacture; // ngày sản xuất
public:
	Smartphone() {
		id = 0;
		brand = "";
		name = "";
		ram = 0;
		price = 0;
		externalMem = 0;
		dateOfManufacture = "";
	}

	Smartphone(const int id) : id(id) {}

	Smartphone(const int id, const string brand, const string name,
		const float price, const int ram, const int externalMem, const string dom);

	void createInfo();

	void showInfo();

	float compareByPrice(const Smartphone& other) const;

	int compareByName(const Smartphone& other) const;
	// getter and setter:
	int getId() const { return id; }

	void setId(const int id);

	string getBrand() const { return brand; }

	string getName() const { return name; }

	void setBrand(const string brand) { this->brand = brand; }

	void setName(const string name) { this->name = name; }

	float getPrice() const { return price; }

	void setPrice(const float price) { this->price = price; }

	int getRam() const { return ram; }

	void setRam(const int amount) { ram = amount; }

	int getExternalMem() const { return externalMem; }

	string getDOM() const { return dateOfManufacture; }

	void setDOM(const string dom) { this->dateOfManufacture = dom; }

	static void setAutoId(const int value) { autoId = value; }

	static int getAutoId() { return autoId; }
};
