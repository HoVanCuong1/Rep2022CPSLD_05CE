﻿#include <iomanip>
#include "Smartphone.h"

/**
 * @author Branium Academy
 * @website braniumacademy.net
 * @version 2021.05
 */

Smartphone::Smartphone(const int id, const string manuf, const string name,
	const int price, const int ram, const int externalMem, const Date& dom) :
	price(price), ram(ram), externalMem(externalMem) {
	setId(id);
	this->manufacturer = manuf;
	this->productName = name;
	this->dateOfManufacture = dom;
}

void Smartphone::createInfo() {
	id = autoId++;
	cout << "Ten san pham: ";
	cin.ignore();
	getline(cin, productName);
	cout << "Hang san xuat: ";
	getline(cin, manufacturer);
	cout << "Bo nho RAM: ";
	cin >> ram;
	cout << "Bo nho ngoai: ";
	cin >> externalMem;
	Date date;
	int day, month, year;
	cout << "Ngay san xuat: ";
	cout << "Ngay: ";
	cin >> day;
	cout << "Thang: ";
	cin >> month;
	cout << "Nam: ";
	cin >> year;
	cout << "Gia ban: ";
	cin >> price;
	date.setDay(day);
	date.setMonth(month);
	date.setYear(year);
	dateOfManufacture = date;
}

void Smartphone::setId(const int id) {
	if (id == 0) {
		this->id = autoId++;
	}
	else {
		this->id = id;
	}
}

void Smartphone::showInfo() {
	string dateString = to_string(dateOfManufacture.getDay());
	dateString += "/";
	dateString += to_string(dateOfManufacture.getMonth());
	dateString += "/";
	dateString += to_string(dateOfManufacture.getYear());
	cout << left << setw(10) << id << setw(20) << productName
		<< setw(20) << manufacturer << setw(15) << price
		<< setw(15) << ram << setw(15) << externalMem
		<< setw(20) << dateString << endl;
}

int Smartphone::compareByproductName(const Smartphone& other) const {
	return productName.compare(other.productName);
}

int Smartphone::compareByPrice(const Smartphone& other) const {
	return price - other.price;
}

int Smartphone::autoId = 10000; // gán giá trị cho biến static id của lớp
