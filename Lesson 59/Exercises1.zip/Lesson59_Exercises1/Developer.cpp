#include <iostream>
#include "Developer.h"
using namespace std;

Developer::Developer() {}

void Developer::showInfo() const {
	Employee::showInfo();
	cout << "Programming language: " << programmingLanguage << endl;
}

string Developer::getProgrammingLanguage() const { return programmingLanguage; }

void Developer::setProgrammingLanguage(string programmingLanguage) { 
	this->programmingLanguage = programmingLanguage; }