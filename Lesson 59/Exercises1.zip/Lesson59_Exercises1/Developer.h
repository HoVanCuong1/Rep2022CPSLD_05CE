#pragma once
#include <string>
#include "Employee.h"
using namespace std;

class Developer : public Employee
{
	string programmingLanguage;
public:
	Developer();
	void showInfo() const;
	string getProgrammingLanguage() const;
	void setProgrammingLanguage(string programmingLanguage);
};

