#include <iostream>
#include "DevLeader.h"
using namespace std;

DevLeader::DevLeader() {}

void DevLeader::showInfo() const {
	Developer::showInfo();
	cout << "Bonus: " << bonus << endl;
	cout << "Ngay thang chuc: " << promotionDay << endl;
}

void DevLeader::setBonus(long bonus) { this->bonus = bonus; }

long DevLeader::getBonus() const { return bonus; }

void DevLeader::setPromotionDay(string promotionDay) {
	this->promotionDay = promotionDay;
}

string DevLeader::getPromotionDay() const { return promotionDay; }