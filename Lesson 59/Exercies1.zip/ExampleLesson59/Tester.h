#pragma once
#include "Employee.h"

class Tester : public Employee
{
	string testTool;
public:
	Tester();
	void showInfo() const;
	void setTestTool(string testTool);
	string getTestTool() const;
};

