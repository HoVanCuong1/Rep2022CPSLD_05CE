#pragma once
#include <string>
using namespace std;

class Employee
{
	string id;
	string fullName;
	string dateOfBirth;
	string gender;
	string email;
	long salary;
public:
	Employee();
	Employee(string id);
	void setId(string id);
	string getId() const;
	void setFullName(string fullName);
	string getFullName() const;
	void setDateOfBirth(string dateOfBirth);
	string getDateOfBirth() const;
	void setGender(string gender);
	string getGender() const;
	void setEmail(string email);
	string getEmail() const;
	void setSalary(long salary);
	long getSalary() const;
	void showInfo() const;
};

