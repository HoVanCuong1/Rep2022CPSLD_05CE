#pragma once
#include <string>
using namespace std;

class Employee
{
	static int autoIncrementId;
	string id;
	string fullName;
	string dateOfBirth;
	string gender;
	string email;
	long salary;
	long kpi;
	int workingDay;
	long totalSalary;
protected:
	virtual long calculateSalary();
public:
	Employee();
	Employee(string id);
	virtual void showInfo() const;
	virtual void getInfoFromKeyboard();
	void setId(string id);
	string getId() const;
	void setFullName(string fullName);
	string getFullName() const;
	void setDateOfBirth(string dateOfBirth);
	string getDateOfBirth() const;
	void setGender(string gender);
	string getGender() const;
	void setEmail(string email);
	string getEmail() const;
	void setSalary(long salary);
	long getSalary() const;
	void setKPI(long kpi);
	long getKPI() const;
	void setWorkingDay(int workingDay);
	int getWorkingDay() const;
	void setTotalSalary(long amount);
	long getTotalSalary();
	static int getCurrentId();
	static void setCurrentId();
};

