#include <iostream>
#include <iomanip>
#include "Tester.h"
using namespace std;

Tester::Tester() {
}

void Tester::showInfo() const {
	cout << left << setw(10) << getId() << setw(25) << getFullName()
		<< setw(16) << getDateOfBirth() << setw(30) << getEmail()
		<< setw(12) << getGender() << setw(15) << getSalary()
		<< setw(20) << testTool << setw(25) << "-" << setw(20) << "-"
		<< setw(20) << "-" << "-" << endl;
}

void Tester::setTestTool(string testTool) { this->testTool = testTool; }

string Tester::getTestTool() const { return testTool; }

void Tester::getInfoFromKeyboard() {
	Employee::getInfoFromKeyboard();
	cout << "Cong cu lam viec: ";
	getline(cin, testTool);
}

long Tester::calculateSalary() {
	long totalSalary = Employee::calculateSalary() + 0.1f * getSalary() * getKPI();
	setTotalSalary(totalSalary);
	return totalSalary;
}