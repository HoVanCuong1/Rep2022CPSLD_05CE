#pragma once
#include <string>
#include "Employee.h"
using namespace std;

class Developer : public Employee
{
	string programmingLanguage;
	string team;
protected:
	long calculateSalary() override;
public:
	Developer();
	void showInfo() const override;
	void getInfoFromKeyboard() override;
	string getProgrammingLanguage() const;
	string getTeam() const;
	void setTeam(string team);
	void setProgrammingLanguage(string programmingLanguage);
};

