#pragma once
#include "Employee.h"

class Tester : public Employee
{
	string testTool;
protected:
	long calculateSalary() override;
public:
	Tester();
	void showInfo() const override;
	void getInfoFromKeyboard() override;
	void setTestTool(string testTool);
	string getTestTool() const;
};

