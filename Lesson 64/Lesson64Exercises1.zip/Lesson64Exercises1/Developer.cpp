#include <iostream>
#include <string>
#include <iomanip>
#include "Developer.h"
using namespace std;

Developer::Developer() {
	setId("DEV" + to_string(getCurrentId()));
}

void Developer::showInfo() const {
	cout << left << setw(10) << getId() << setw(25) << getFullName()
		<< setw(16) << getDateOfBirth() << setw(30) << getEmail()
		<< setw(12) << getGender() << setw(15) << getSalary() << setw(20) 
		<< "-" << setw(25) << team << setw(20) << programmingLanguage 
		<< setw(20) << "-" << "-" << endl;
}

string Developer::getProgrammingLanguage() const { return programmingLanguage; }

void Developer::setProgrammingLanguage(string programmingLanguage) { 
	this->programmingLanguage = programmingLanguage; 
}

string Developer::getTeam() const { return team; }

void Developer::setTeam(string team) { this->team = team; }

void Developer::getInfoFromKeyboard() {
	Employee::getInfoFromKeyboard();
	cout << "Ngon ngu lap trinh: ";
	getline(cin, programmingLanguage);
	cout << "Ten nhom: ";
	getline(cin, team);
	
}

long Developer::calculateSalary() {
	long totalSalary = (getSalary() * getWorkingDay() * 1.0f / 22 
		+ 0.2f * getSalary() * getKPI());
	setTotalSalary(totalSalary);
	return totalSalary;
}