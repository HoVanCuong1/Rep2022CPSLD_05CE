#pragma once
#include "Employee.h"

class Tester : public Employee
{
	string testTool;
public:
	Tester();
	void showInfo() const override;
	void getInfoFromKeyboard() override;
	long calculateSalary() override;
	void setTestTool(string testTool);
	string getTestTool() const;
};

