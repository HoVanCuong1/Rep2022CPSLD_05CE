#include <iostream>
#include <iomanip>
#include "DevLeader.h"
using namespace std;

DevLeader::DevLeader() {
	bonus = 0;
}

void DevLeader::showInfo() const {
	cout << left << setw(10) << getId() << setw(25) << getFullName()
		<< setw(16) << getDateOfBirth() << setw(30) << getEmail()
		<< setw(12) << getGender() << setw(15) << getSalary() << setw(20) << "-"
		<< setw(25) << getTeam() << setw(20) << getProgrammingLanguage()
		<< setw(20) << promotionDay << setw(15) << bonus << endl;
}

void DevLeader::getInfoFromKeyboard() {
	Developer::getInfoFromKeyboard();
	cout << "Ngay thang chuc: ";
	getline(cin, promotionDay);
	cout << "Muc thuong: ";
	cin >> bonus;
	cin.ignore();
}

void DevLeader::setBonus(long bonus) { this->bonus = bonus; }

long DevLeader::getBonus() const { return bonus; }

void DevLeader::setPromotionDay(string promotionDay) {
	this->promotionDay = promotionDay;
}

string DevLeader::getPromotionDay() const { return promotionDay; }

long DevLeader::calculateSalary() {
	long totalSalary = Developer::calculateSalary() + 0.6f * getSalary() + bonus;
	setTotalSalary(totalSalary);
	return totalSalary;
}