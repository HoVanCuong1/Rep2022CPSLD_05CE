#pragma once
#include <string>
#include "Employee.h"
using namespace std;

class Developer : public Employee
{
	char programmingLanguage[20];
	char team[20];
protected:
	long calculateSalary() override;
public:
	Developer();
	virtual void showInfo() override;
	virtual void getInfoFromKeyboard() override;
	virtual void writeToFile(ofstream&) override;
	virtual void readDataFromFile(ifstream&) override;
	virtual void resetData() override;
	string getProgrammingLanguage();
	string getTeam();
	void setTeam(string team);
	void setProgrammingLanguage(string programmingLanguage);
};

