#include <string>
#include <iostream>
#include <iomanip>
#include "Employee.h"
using namespace std;

int Employee::autoIncrementId = 100;

Employee::Employee() {
	autoIncrementId++;
	salary = 0;
	totalSalary = 0;
	kpi = 0;
	workingDay = 0;
}

Employee::Employee(string id) :salary(0), workingDay(0), totalSalary(0), kpi(0) {
	setId(id);
}

void Employee::setId(string id) { 
	int len = id.length();
	len = len < 20 ? len : 19;
	id.copy(this->id, len);
	this->id[len] = '\0';
}

string Employee::getId() { return id; }

void Employee::setFullName(string fullName) { 
	int len = fullName.length();
	len = len < 40 ? len : 39;
	fullName.copy(this->fullName, len);
	this->fullName[len] = '\0';
}

string Employee::getFullName() { return fullName; }

void Employee::setDateOfBirth(string dateOfBirth) { 
	int len = dateOfBirth.length();
	len = len < 20 ? len : 19;
	dateOfBirth.copy(this->dateOfBirth, len);
	this->dateOfBirth[len] = '\0';
}

string Employee::getDateOfBirth() { return dateOfBirth; }

void Employee::setGender(string gender) { 
	int len = gender.length();
	len = len < 10 ? len : 9;
	gender.copy(this->gender, len);
	this->gender[len] = '\0';
}

string Employee::getGender() { return gender; }

void Employee::setEmail(string email) { 
	int len = email.length();
	len = len < 40 ? len : 39;
	email.copy(this->email, len);
	this->email[len] = '\0';
}

string Employee::getEmail() { return email; }

void Employee::setSalary(long salary) { this->salary = salary > 0 ? salary : 0; }

long Employee::getSalary() const { return salary; }

void Employee::setKPI(long kpi) { this->kpi = kpi; }

long Employee::getKPI() const { return kpi; }

int Employee::getCurrentId() { return autoIncrementId; }

void Employee::setCurrentId(int id) { 
	autoIncrementId = id == 0 ? ++autoIncrementId : id;
}

void Employee::resetData() {
	id[0] = '\0';
	fullName[0] = '\0';
	email[0] = '\0';
	id[0] = '\0';
	dateOfBirth[0] = '\0';
	gender[0] = '\0';
	salary = 0;
	workingDay = 0;
	kpi = 0;
	totalSalary = 0;
}

void Employee::setWorkingDay(int workingDay) { 
	if (workingDay < 0) {
		this->workingDay = 0;
	}
	else if (workingDay > 31) {
		this->workingDay = 31;
	}
	else {
		this->workingDay = workingDay;
	}
}

int Employee::getWorkingDay() const { return workingDay; }

void Employee::setTotalSalary(long amount = 0) { this->totalSalary = (amount > 0) ? amount : 0; }

long Employee::getTotalSalary() { 
	calculateSalary();
	return totalSalary; 
}

void Employee::getInfoFromKeyboard() {
	cout << "Ho va ten: ";
	cin.getline(fullName, 39);
	cout << "Nhap email: ";
	cin.getline(email, 39);
	cout << "Nhap ngay sinh: ";
	cin.getline(dateOfBirth, 19);
	cout << "Nhap gioi tinh: ";
	cin.getline(gender, 9);
	cout << "Nhap luong: ";
	cin >> salary;
	cout << "So ngay lam viec trong thang: ";
	cin >> workingDay;
	cout << "KPI dat duoc: ";
	cin >> kpi;
	cin.ignore();
}
