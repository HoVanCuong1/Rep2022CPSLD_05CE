#pragma once
#include "Employee.h"

class Tester : public Employee
{
	friend void writeFile(ofstream&, Tester&);
	char testTool[40];
protected:
	long calculateSalary() override;
public:
	Tester();
	virtual void showInfo() override;
	virtual void getInfoFromKeyboard() override;
	virtual void writeToFile(ofstream&) override;
	virtual void readDataFromFile(ifstream&) override;
	virtual void resetData() override;
	void setTestTool(string testTool);
	string getTestTool() const;
};

