#include <iostream>
#include <iomanip>
#include <fstream>
#include "Tester.h"
#include "Developer.h"
#include "DevLeader.h"
using namespace std;

int main() {
	/*
	ofstream ofs("DEV.DAT", ios::out);
	Developer dev;
	dev.getInfoFromKeyboard();
	ofs.write(reinterpret_cast<const char*>(&dev), sizeof(Developer));
	ofs.close();
	*/
	Employee *dev1 = new Developer();
	ifstream ifs("DEV.DAT", ios::in|ios::binary);
	while (!ifs.eof()) {
		ifs.read(reinterpret_cast<char*>(dev1), sizeof(Developer));
		//dev->readDataFromFile(ifs);
		if (ifs.eof()) {
			break;
		}
		dev1->showInfo();
	}
	ifs.close();
	return 0;
}

/*
cout << left << setw(10) << dev->getId() << setw(25) << dev->getFullName()
			<< setw(16) << dev->getDateOfBirth() << setw(30) << dev->getEmail()
			<< setw(12) << dev->getGender() << setw(15) << dev->getSalary() << setw(20)
			<< "-" << setw(25) << dev->getTeam() << setw(20) << dev->getProgrammingLanguage()
			<< setw(20) << "-" << setw(15) << "-" << endl;
*/