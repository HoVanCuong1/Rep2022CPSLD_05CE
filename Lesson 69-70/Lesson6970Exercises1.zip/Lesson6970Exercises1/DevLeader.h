#pragma once
#include <string>
#include "Developer.h"
using namespace std;

class DevLeader : public Developer
{
	long bonus;
	char promotionDay[20];
public:
	DevLeader();
	virtual void showInfo() override;
	virtual void getInfoFromKeyboard() override;
	virtual long calculateSalary() override;
	virtual void writeToFile(ofstream&) override;
	virtual void readDataFromFile(ifstream&) override;
	virtual void resetData() override;
	void setBonus(long bonus);
	long getBonus() const;
	void setPromotionDay(string promotionDay);
	string getPromotionDay() const;
};

