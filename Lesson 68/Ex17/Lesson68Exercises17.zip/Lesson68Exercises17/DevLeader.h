#pragma once
#include <string>
#include "Developer.h"
using namespace std;

class DevLeader : public Developer
{
	long bonus;
	string promotionDay;
public:
	DevLeader();
	void showInfo() const override;
	void getInfoFromKeyboard() override;
	long calculateSalary() override;
	virtual void writeToFile(ofstream&) const override;
	virtual void extractData(string) override;
	void setBonus(long bonus);
	long getBonus() const;
	void setPromotionDay(string promotionDay);
	string getPromotionDay() const;
};

