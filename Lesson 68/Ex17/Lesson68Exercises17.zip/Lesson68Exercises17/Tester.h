#pragma once
#include "Employee.h"

class Tester : public Employee
{
	friend void writeFile(ofstream&, Tester&);
	string testTool;
protected:
	long calculateSalary() override;
public:
	Tester();
	void showInfo() const override;
	void getInfoFromKeyboard() override;
	virtual void writeToFile(ofstream&) const override;
	virtual void extractData(string) override;
	void setTestTool(string testTool);
	string getTestTool() const;
};

