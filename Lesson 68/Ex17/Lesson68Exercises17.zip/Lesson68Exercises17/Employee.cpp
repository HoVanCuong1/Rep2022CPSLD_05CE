#include <string>
#include <iostream>
#include <iomanip>
#include "Employee.h"
using namespace std;

int Employee::autoIncrementId = 100;

Employee::Employee() {
	id = "EMP" + to_string(autoIncrementId);
	autoIncrementId++;
	salary = 0;
	totalSalary = 0;
	kpi = 0;
	workingDay = 0;
}

Employee::Employee(string id) :id(id), salary(0), workingDay(0), totalSalary(0), kpi(0) {}

void Employee::setId(string id) { this->id = id; }

string Employee::getId() const { return id; }

void Employee::setFullName(string fullName) { this->fullName = fullName; }

string Employee::getFullName() const { return fullName; }

void Employee::setDateOfBirth(string dateOfBirth) { this->dateOfBirth = dateOfBirth; }

string Employee::getDateOfBirth() const { return dateOfBirth; }

void Employee::setGender(string gender) { this->gender = gender; }

string Employee::getGender() const { return gender; }

void Employee::setEmail(string email) { this->email = email; }

string Employee::getEmail() const { return email; }

void Employee::setSalary(long salary) { this->salary = salary > 0 ? salary : 0; }

long Employee::getSalary() const { return salary; }

void Employee::setKPI(long kpi) { this->kpi = kpi; }

long Employee::getKPI() const { return kpi; }

int Employee::getCurrentId() { return autoIncrementId; }

void Employee::setCurrentId(int id) { 
	autoIncrementId = id == 0 ? ++autoIncrementId : id;
}

void Employee::setWorkingDay(int workingDay) { 
	if (workingDay < 0) {
		this->workingDay = 0;
	}
	else if (workingDay > 31) {
		this->workingDay = 31;
	}
	else {
		this->workingDay = workingDay;
	}
}

int Employee::getWorkingDay() const { return workingDay; }

void Employee::setTotalSalary(long amount = 0) { this->totalSalary = (amount > 0) ? amount : 0; }

long Employee::getTotalSalary() { 
	calculateSalary();
	return totalSalary; 
}

void Employee::getInfoFromKeyboard() {
	cout << "Ho va ten: ";
	getline(cin, fullName);
	cout << "Nhap email: ";
	getline(cin, email);
	cout << "Nhap ngay sinh: ";
	getline(cin, dateOfBirth);
	cout << "Nhap gioi tinh: ";
	getline(cin, gender);
	cout << "Nhap luong: ";
	cin >> salary;
	cout << "So ngay lam viec trong thang: ";
	cin >> workingDay;
	cout << "KPI dat duoc: ";
	cin >> kpi;
	cin.ignore();
}
