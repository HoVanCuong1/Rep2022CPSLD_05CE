﻿#include <iomanip>
#include "Smartphone.h"

/**
 * @author Branium Academy
 * @website braniumacademy.net
 * @version 2021.05
 */

Smartphone::Smartphone(const int id, const string manuf, const string name,
	const int price, const int ram, const int externalMem, const Date& dom) :
	price(price), ram(ram), externalMem(externalMem) {
	setId(id);
	this->manufacturer = manuf;
	this->productName = name;
	this->dateOfManufacture = dom;
}

void Smartphone::setId(const int id) {
	if (id == 0) {
		this->id = autoId++;
	}
	else {
		this->id = id;
	}
}

int Smartphone::compareByproductName(const Smartphone& other) const {
	return productName.compare(other.productName);
}

int Smartphone::compareByPrice(const Smartphone& other) const {
	return price - other.price;
}

int Smartphone::autoId = 10000; // gán giá trị cho biến static id của lớp
