﻿#pragma once
#include "Smartphone.h"

// lớp bạn của lớp smartphone
class SmartPhoneController
{
public:
	// thêm mới sản phẩm
	void add(Smartphone* smartphones, int& size);
	// sửa giá sản phẩm
	void editPrice(Smartphone& s);
	// xóa sản phẩm
	bool remove(Smartphone* smartphones, int& size, int id);
	// xóa sản phẩm theo mã sản phẩm
	int findById(Smartphone* smartphones, int size, int id);
	// tìm sản phẩm theo tên
	void findByName(Smartphone* smartphones, int size, 
		Smartphone* searchResult, int& resultSize, string name);
	// tìm sản phẩm theo hãng
	void findByBrand(Smartphone* smartphones, int size, 
		Smartphone* searchResult, int& resultSize, string brand);
	// hiển thị danh sách smartphone
	void showSmatphones(const Smartphone* smartphones, int size);
	// sắp xếp theo mã sản phẩm tăng dần
	void sortById(Smartphone* smartphones, int size);
	// sắp xếp theo giá sản phẩm giảm dần
	void sortByPrice(Smartphone* smartphones, int size);
};

