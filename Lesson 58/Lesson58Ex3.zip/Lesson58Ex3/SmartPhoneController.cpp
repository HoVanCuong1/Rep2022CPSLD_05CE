﻿#include<iostream>
#include<iomanip>
#include "SmartPhoneController.h"
using namespace std;

void SmartPhoneController::add(Smartphone* smartphones, int& size) {
	Smartphone smartphone;
	smartphone.setId(0);
	cout << "Ten san pham: ";
	cin.ignore();
	getline(cin, smartphone.productName);
	cout << "Hang san xuat: ";
	getline(cin, smartphone.manufacturer);
	cout << "Bo nho RAM: ";
	cin >> smartphone.ram;
	cout << "Bo nho ngoai: ";
	cin >> smartphone.externalMem;
	Date date;
	int day, month, year;
	cout << "Ngay san xuat: ";
	cout << "Ngay: ";
	cin >> day;
	cout << "Thang: ";
	cin >> month;
	cout << "Nam: ";
	cin >> year;
	cout << "Gia ban: ";
	cin >> smartphone.price;
	date.setDay(day);
	date.setMonth(month);
	date.setYear(year);
	smartphone.dateOfManufacture = date;
	smartphones[size++] = smartphone;
}

void SmartPhoneController::editPrice(Smartphone& s) {
	int price;
	cout << "Nhap gia moi cho san pham: ";
	cin >> price;
	s.price = price;
}

bool SmartPhoneController::remove(Smartphone* smartphones, int& size, int id) {
	int removeIndex = findById(smartphones, size, id);
	if (removeIndex >= 0) {
		for (int j = removeIndex; j < size - 1; j++)
		{
			smartphones[j] = smartphones[j + 1];
		}
		size--;
		return true;
	}
	return false; // xóa thất bại
}

void SmartPhoneController::findByName(Smartphone* smartphones, int size,
	Smartphone* searchResult, int& resultSize, string name) {
	for (int i = 0; i < size; i++)
	{
		if (smartphones[i].productName.compare(name) == 0) {
			searchResult[resultSize++] = smartphones[i];
		}
	}
}

void SmartPhoneController::findByBrand(Smartphone* smartphones, int size,
	Smartphone* searchResult, int& resultSize, string brand) {
	for (int i = 0; i < size; i++)
	{
		if (smartphones[i].manufacturer.compare(brand) == 0) {
			searchResult[resultSize++] = smartphones[i];
		}
	}
}

void SmartPhoneController::showSmatphones(const Smartphone* smartphones, int size) {
	for (int i = 0; i < size; i++)
	{
		auto smartphone = smartphones[i];
		string dateString = to_string(smartphone.dateOfManufacture.getDay());
		dateString += "/";
		dateString += to_string(smartphone.dateOfManufacture.getMonth());
		dateString += "/";
		dateString += to_string(smartphone.dateOfManufacture.getYear());
		cout << left << setw(10) << smartphone.id << setw(20) << smartphone.productName
			<< setw(20) << smartphone.manufacturer << setw(15) << smartphone.price
			<< setw(15) << smartphone.ram << setw(15) << smartphone.externalMem
			<< setw(20) << dateString << endl;
	}
}

int SmartPhoneController::findById(Smartphone* smartphones, int size, int id) {
	for (int i = 0; i < size; i++)
	{
		if (smartphones[i].getId() == id) {
			return i;
		}
	}
	return -1;
}

void SmartPhoneController::sortById(Smartphone* smartphones, int size) {
	for (int i = 0; i < size - 1; i++)
	{
		for (int j = size - 1; j > i; j--)
		{
			if (smartphones[j - 1].id > smartphones[j].id) {
				swap(smartphones[j], smartphones[j - 1]);
			}
		}
	}
}

void SmartPhoneController::sortByPrice(Smartphone* smartphones, int size) {
	for (int i = 0; i < size - 1; i++)
	{
		for (int j = size - 1; j > i; j--)
		{
			if (smartphones[j - 1].price - smartphones[j].price < 0) {
				swap(smartphones[j], smartphones[j - 1]);
			}
		}
	}
}