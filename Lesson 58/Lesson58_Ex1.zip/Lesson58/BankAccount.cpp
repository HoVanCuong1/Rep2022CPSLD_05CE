#include <iostream>
#include <string>
#include "BankAccount.h"

void BankAccount::setId(int id) { this->id = id; }

int BankAccount::getId() { return id; }

void BankAccount::setOwner(string owner) { this->owner = owner; }

string BankAccount::getOwner() { return owner; }

void BankAccount::setCardNumber(string cardNumber) { this->cardNumber = cardNumber; }

string BankAccount::getCardNumber() { return cardNumber; }

void BankAccount::setBallance(long ballance) { this->ballance = ballance; }

long BankAccount::getBallance() { return ballance; }

void BankAccount::setStartDate(string startDate) { this->startDate = startDate; }

string BankAccount::getStartDate() { return startDate; }

void BankAccount::setEndDate(string endDate) { this->endDate = endDate; }

string BankAccount::getEndDate() { return endDate; }

void BankAccount::setBankName(string bankName) { this->bankName = bankName; }

string BankAccount::getBankName() { return bankName; }

BankAccount::BankAccount() {
	id = autoIncrementId++;
	ballance = 0;
}

BankAccount::BankAccount(string owner, string cardNumber,
	long amount, string startDate, string endDate, string bankName) {
	this->id = autoIncrementId++;
	this->owner = owner;
	this->cardNumber = cardNumber;
	this->ballance = ballance;
	this->startDate = startDate;
	this->endDate = endDate;
	this->bankName = bankName;
}

void checkBallance(BankAccount acc) {
	cout << "=========================================\n";
	cout << "Bank Account Id: " << acc.id << endl;
	cout << "Owner: " << acc.owner << endl;
	cout << "Card Number: " << acc.cardNumber << endl;
	cout << "Ballance: " << acc.ballance << endl;
	cout << "End Date: " << acc.endDate << endl;
}

bool withdraw(BankAccount& acc, long amount) {
	cout << "=========================================\n";
	if (amount > 0 && amount <= acc.ballance) {
		acc.ballance -= amount;
		cout << "Withdrawn successfully." << endl;
		cout << "Bank Account Id: " << acc.id << endl;
		cout << "Account " << acc.cardNumber << " -" << amount << endl;
		cout << "Your current ballance is: " << acc.ballance << endl;
		return true;
	}
	else {
		cout << "Your ballance is not enough. "
			<< "Please try other amount." << endl;
		return false;
	}
}

bool deposit(BankAccount& acc, long amount) {
	cout << "=========================================\n";
	if (amount > 0) {
		acc.ballance += amount;
		cout << "Deposit successfully." << endl;
		cout << "Transaction +" << amount << endl;
		cout << "Bank Account Id: " << acc.id << endl;
		cout << "Account " << acc.cardNumber << endl;
		cout << "Your current ballance is " << acc.ballance << endl;
		return true;
	}
	else {
		cout << "Invalid deposit amount. Please check again." << endl;
		return false;
	}
}

bool transfer(BankAccount& currentAcc, BankAccount& otherAcc, long amount) {
	cout << "======================================\n";
	if (amount < currentAcc.ballance) {
		otherAcc.ballance += amount;
		currentAcc.ballance -= amount;
		cout << "Transferred successfully." << endl;
		cout << "Account " << currentAcc.cardNumber << " -" << amount << endl;
		cout << "Account " << otherAcc.cardNumber << " +" << amount << endl;
		cout << "Your current ballance is " << currentAcc.ballance << endl;
		return true;
	}
	else {
		cout << "Transfer failed. Ballance is not enough." << endl;
		return false;
	}
}

int BankAccount::getCurentBankAccountId() {
	return autoIncrementId;
}