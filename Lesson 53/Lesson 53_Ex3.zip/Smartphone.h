﻿#include <iostream>
#include <string>
using namespace std;

#pragma once

/**
 * @author Branium Academy
 * @website braniumacademy.net
 * @version 2021.05
 */

class Smartphone {
private:
	int id; // mã sản phẩm
	string brand; // hãng
	string name; // tên sản phẩm
	float price; // giá bán
	int ram; // bộ nhớ ram
	int externalMem; // bộ nhớ ngoài
	string dateOfManufacture; // ngày sản xuất
public:
	Smartphone() {
		id = 0;
		brand = "";
		name = "";
		ram = 0;
		price = 0;
		externalMem = 0;
		dateOfManufacture = "";
	}

	Smartphone(int id) : id(id) {}

	Smartphone(int id, string brand, string name, float price, int ram, int externalMem, string dom);

	void createInfo();

	void showInfo();

	float compareByPrice(Smartphone& other);

	int compareByName(Smartphone& other);
	// getter and setter:
	int getId() { return id; }

	void setId(int id) { this->id = id; }

	string getBrand() { return brand; }

	string getName() { return name; }

	void setBrand(string brand) { this->brand = brand; }

	void setName(string name) { this->name = name; }

	float getPrice() { return price; }

	void setPrice(float price) { this->price = price; }

	int getRam() { return ram; }

	void setRam(int amount) { ram = amount; }

	int getExternalMem() { return externalMem; }

	string getDOM() { return dateOfManufacture; }

	void setDOM(string dom) { this->dateOfManufacture = dom; }
};

