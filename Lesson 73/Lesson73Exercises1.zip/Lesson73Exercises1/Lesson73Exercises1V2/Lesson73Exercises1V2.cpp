/**
* @author Branium Academy
* website braniumacademy.net
* version 2021.06
* target overloading operator using friend functions
*/

#include <iostream>
#include "Date.h"
using namespace std;

int main()
{
	Date d1;
	Date d2;
	cin >> d1;
	cin >> d2;
	cout << "=======================\n";
	cout << "d1: " << d1;
	cout << "d2: " << d2;
	cout << "=======================\n";
	cout << "d1 == d2 ? " << (d1 == d2) << endl;
	cout << "d1 != d2 ? " << (d1 != d2) << endl;
	cout << "d1 < d2 ? " << (d1 < d2) << endl;
	cout << "d1 <= d2 ? " << (d1 <= d2) << endl;
	cout << "d1 > d2 ? " << (d1 > d2) << endl;
	cout << "d1 >= d2 ? " << (d1 >= d2) << endl;
	cout << "=======================\n";
	d1++;
	cout << "After d1++: " << d1;
	++d1;
	cout << "After ++d1: " << d1;
	d2--;
	cout << "After d2--: " << d2;
	--d2;
	cout << "After --d2: " << d2;
	cout << "=======================\n";
	d1 += 5;
	cout << "After d1 += 5: " << d1;
	d1 -= 5;
	cout << "After d1 -= 5: " << d1;
	cout << "=======================\n";

	return 0;
}