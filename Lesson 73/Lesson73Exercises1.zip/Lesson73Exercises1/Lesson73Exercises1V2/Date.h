/**
* @author Branium Academy
* website braniumacademy.net
* version 2021.06
* target overloading operator using friend functions
*/


#pragma once
#include <iostream>

class Date {
	friend std::ostream& operator << (std::ostream&, const Date&);
	friend std::istream& operator >> (std::istream&, Date&);
	friend Date operator ++ (Date&);
	friend Date operator += (Date& , int amount);
	friend Date operator -= (Date& , int amount);
	friend Date operator ++ (Date& , int);
	friend Date operator -- (Date&);
	friend Date operator -- (Date&, int);
	friend bool operator == (const Date&, const Date&);
	friend bool operator != (const Date&, const Date&);
	friend bool operator < (const Date&, const Date&);
	friend bool operator <= (const Date&, const Date&);
	friend bool operator > (const Date&, const Date&);
	friend bool operator >= (const Date&, const Date&);
	int day;
	int month;
	int year;
public:
	Date();

	Date(int day, int month, int year);

	bool endOfMonth(int day);

	bool startOfMonth(int day);

	void setYear(int year);

	void setMonth(int month);

	void setDay(int day);

	int getDay() const;

	int getMonth() const;

	int getYear() const;

	bool isLeapYear(int);
};
