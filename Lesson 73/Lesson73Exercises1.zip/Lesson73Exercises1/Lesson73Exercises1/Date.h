/**
* @author Branium Academy
* website braniumacademy.net
* version 2021.06
* target overloading operator using class member functions
*/


#pragma once
#include <iostream>

class Date {
	friend std::ostream& operator << (std::ostream&, const Date&);
	friend std::istream& operator >> (std::istream&, Date&);
	int day;
	int month;
	int year;
public:
	Date();

	Date(int day, int month, int year);

	Date operator ++ ();

	Date operator += (int amount);

	Date operator -= (int amount);

	Date operator ++ (int);

	Date operator -- ();

	Date operator -- (int);

	bool operator == (const Date&);

	bool operator != (const Date&);

	bool operator < (const Date&);

	bool operator <= (const Date&);

	bool operator > (const Date&);

	bool operator >= (const Date&);

	bool endOfMonth(int day);

	bool startOfMonth(int day);

	void setYear(int year);

	void setMonth(int month);

	void setDay(int day);

	int getDay() const;

	int getMonth() const;

	int getYear() const;

	bool isLeapYear(int);
};
