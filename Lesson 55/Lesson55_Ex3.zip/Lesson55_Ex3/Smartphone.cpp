﻿#include <iomanip>
#include "Smartphone.h"

/**
 * @author Branium Academy
 * @website braniumacademy.net
 * @version 2021.05
 */

Smartphone::Smartphone(int id, string brand, string name,
	float price, int ram, int externalMem, string dom) :
	price(price), ram(ram), externalMem(externalMem) {
	setId(id);
	this->brand = brand;
	this->name = name;
	this->dateOfManufacture = dom;
}

void Smartphone::createInfo() {
	id = autoId++;
	cout << "Ten san pham: ";
	cin.ignore();
	getline(cin, name);
	cout << "Hang san xuat: ";
	getline(cin, brand);
	cout << "Bo nho RAM: ";
	cin >> ram;
	cout << "Bo nho ngoai: ";
	cin >> externalMem;
	cout << "Ngay san xuat: ";
	cin.ignore();
	getline(cin, dateOfManufacture);
	cout << "Gia ban: ";
	cin >> price;
}

void Smartphone::setId(int id) {
	if (id == 0) {
		this->id = autoId++;
	}
	else {
		this->id = id;
	}
}

void Smartphone::showInfo() {
	cout << left << setw(10) << id << setw(20) << name
		<< setw(20) << brand << setw(15) << price
		<< setw(15) << ram << setw(15) << externalMem
		<< setw(20) << dateOfManufacture << endl;
}

int Smartphone::compareByName(Smartphone& other) {
	return name.compare(other.name);
}

float Smartphone::compareByPrice(Smartphone& other) {
	return price - other.price;
}

int Smartphone::autoId = 10000; // gán giá trị cho biến static id của lớp
